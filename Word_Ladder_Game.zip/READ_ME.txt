The project is made in python language.
 I have used JSON file from this link: 
https://raw.githubusercontent.com/adambom/dictionary/master/dictionary.json 
 
download the file and store with name �dictionary.json� and place it in the same folder.
