# @author Raveel Abdullah

import json 
from collections import deque

def getwordlist(word, wordDict, discovered):
    wordList = list()
    discoveredWordList = list()
    for i, charWord in enumerate(word):
        char = charWord
        if charWord == 'Z':
            char = 'A'
        else:
            char = chr(ord(charWord) + 1)    #increment by 1 character

        while char != charWord:
            if ord(char) > ord('Z'):
                char = 'A'
                if char == charWord:
                    break

            tempWord = list(word)
            tempWord[i] = char
            strWord = ''.join(tempWord)

            
            if strWord in wordDict:
                if strWord not in discovered:
                    wordList.append(strWord)
                else:
                    discoveredWordList.append(strWord)


            char = chr(ord(char) + 1)


            #print(charWord ,char, word, strWord)
            
    return wordList, discoveredWordList
    
####################################################################################
#open and read the json dictionary file

fileDict = open("dictionary.json", 'r')
wordDict = json.loads(fileDict.read())

#startWord = "PULL"
#endWord = "PUSH"   #goal state

print("==================== Welcome to Word Ladder Game =====================\n")
startWord = input("Enter first word: ").upper() #convert to uppercase
endWord = input("Enter second word: ").upper()  #convert to lowercase

lenStartWord = len(startWord)
lenEndWord = len(endWord)


if startWord in wordDict and endWord in wordDict and lenStartWord == lenEndWord:
    print("Valid Input...")
else:
    raise("Error! invalid input...")
    

discovered = set()  #maintain the discovered nodes
graph = dict()   #maintain the graph
tree = dict()

queueList = deque() #list for implementing bfs, append(), popleft()
top = 0     #peek the top element of queue

discovered.add(startWord)
queueList.append(startWord)
graph[startWord] = (startWord,)


chainFound = False

while len(queueList) != 0:
    word = queueList.popleft()
    if word == endWord:
        chainFound = True
        print("chain found")
#        print(graph[word])

    wordList, discoveredWordList = getwordlist(word, wordDict, discovered)
    
    for chainWord in wordList:
        queueList.append(chainWord) #append node in queue
        discovered.add(chainWord)   #mark word as discovered
        graph[chainWord] = (word,)

    graphTuple = graph[word]
    tempTuple = (wordList + discoveredWordList,)
    graph[word] = graphTuple + tempTuple

if chainFound is not True:
    print("no chain found")


#iterating over the chain
nextParent = endWord
goal = startWord
chain = list()
chain.append(nextParent)
while nextParent != goal:
    if nextParent in graph:
        nextParent = graph[nextParent][0]
        chain.append(nextParent)

chain.reverse()
for nextWord in chain:
    print(nextWord, end="->")

print("|")

###########################################################################

wordDictList = (wordDict.keys())

############################################################################
tree = dict()
queueList = deque()

discovered = set()
#print(discovered)

#while len(queue(List) != 0:

    #print(queueList)

#print(graph[startWord])

#for key in graph:
#    print(key ,graph[key])




